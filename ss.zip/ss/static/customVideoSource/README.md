
For Firefox, to disable CORS, 
https://stackoverflow.com/questions/17088609/disable-firefox-same-origin-policy
about:config > security.fileuri.strict_origin_policy > false
